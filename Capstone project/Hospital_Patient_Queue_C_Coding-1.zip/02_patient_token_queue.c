/* Module 2 example - Patient Token Queue (based on the PPT example) */
#include <stdio.h>

int main(void)
{
    int queue[5];
    int front = 0, rear = -1;
    int i;

    printf("PATIENT QUEUE MANAGEMENT\n");

    for (i = 0; i < 3; i++) {
        rear++;
        printf("Enter Patient Token: ");
        if (scanf("%d", &queue[rear]) != 1) {
            printf("Invalid token.\n");
            return 1;
        }
    }

    printf("\nPatients Waiting in Queue:\n");
    for (i = front; i <= rear; i++) {
        printf("Patient Token: %d\n", queue[i]);
    }

    printf("\nCalling Next Patient: %d\n", queue[front]);
    front++;

    printf("\nUpdated Waiting Queue:\n");
    for (i = front; i <= rear; i++) {
        printf("Patient Token: %d\n", queue[i]);
    }

    return 0;
}
