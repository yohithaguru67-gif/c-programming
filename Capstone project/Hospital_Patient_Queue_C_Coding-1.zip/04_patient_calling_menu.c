/* Module 4 - Patient Calling (based on the PPT example) */
#include <stdio.h>

#define SIZE 5

struct Patient {
    char name[20];
    int age;
};

int main(void)
{
    struct Patient q[SIZE];
    int front = 0, rear = -1;
    int choice, i;

    do {
        printf("\n1. Add Patient  2. Call Patient  3. Display  4. Exit\n");
        printf("Enter choice: ");

        if (scanf("%d", &choice) != 1) {
            printf("Invalid choice.\n");
            return 1;
        }

        switch (choice) {
            case 1:
                if (rear == SIZE - 1) {
                    printf("Queue Full\n");
                } else {
                    rear++;
                    printf("Enter name and age: ");
                    if (scanf("%19s %d", q[rear].name, &q[rear].age) != 2 ||
                        q[rear].age < 0) {
                        printf("Invalid patient details.\n");
                        rear--;
                    }
                }
                break;

            case 2:
                if (front > rear) {
                    printf("No patients waiting\n");
                } else {
                    printf("Calling: %s, Age: %d\n",
                           q[front].name, q[front].age);
                    front++;
                    if (front > rear) {
                        front = 0;
                        rear = -1;
                    }
                }
                break;

            case 3:
                if (front > rear) {
                    printf("No patients waiting\n");
                } else {
                    printf("Waiting patients:\n");
                    for (i = front; i <= rear; i++) {
                        printf("%s - %d\n", q[i].name, q[i].age);
                    }
                }
                break;

            case 4:
                printf("Exiting patient queue system.\n");
                break;

            default:
                printf("Invalid choice. Try again.\n");
        }
    } while (choice != 4);

    return 0;
}
