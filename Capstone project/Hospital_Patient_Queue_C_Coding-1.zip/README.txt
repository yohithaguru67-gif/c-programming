HOSPITAL PATIENT QUEUE AND EMERGENCY PRIORITIZING SYSTEM
C source code from the uploaded Capstone Review 2 PPT

FILES
1. 01_patient_registration.c  - Module 1: Patient registration
2. 02_patient_token_queue.c   - Module 2 PPT token queue example
3. 03_queue_operations.c      - Module 3: enqueue, dequeue and display
4. 04_patient_calling_menu.c  - Module 4: add, call and display patients

HOW TO COMPILE (GCC)
Open a terminal in this folder and compile one file at a time:

gcc 01_patient_registration.c -o registration
gcc 02_patient_token_queue.c -o token_queue
gcc 03_queue_operations.c -o queue_operations
gcc 04_patient_calling_menu.c -o patient_calling

HOW TO RUN
Linux/macOS:
./registration
./token_queue
./queue_operations
./patient_calling

Windows (MinGW):
registration.exe
token_queue.exe
queue_operations.exe
patient_calling.exe

NOTE
These are separate educational C examples corresponding to the code shown
in the PPT. They are not one integrated hospital application. The PPT
describes emergency/urgent/normal priority and file storage, but the code
examples shown do not fully implement priority sorting or file handling.
The priority category must be entered by authorized hospital staff; this
prototype does not assess or diagnose medical urgency.
