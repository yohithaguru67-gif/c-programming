/* Module 1 - Patient Registration (based on the PPT example) */
#include <stdio.h>

int main(void)
{
    int id, age;
    char name[50];

    printf("HOSPITAL PATIENT REGISTRATION\n");

    printf("Enter Patient ID: ");
    if (scanf("%d", &id) != 1) {
        printf("Invalid patient ID.\n");
        return 1;
    }

    printf("Enter Patient Name: ");
    if (scanf("%49s", name) != 1) {
        printf("Invalid patient name.\n");
        return 1;
    }

    printf("Enter Patient Age: ");
    if (scanf("%d", &age) != 1 || age < 0) {
        printf("Invalid patient age.\n");
        return 1;
    }

    printf("\n--- Patient Details ---\n");
    printf("Patient ID: %d\n", id);
    printf("Patient Name: %s\n", name);
    printf("Patient Age: %d\n", age);
    printf("Patient Registered Successfully!\n");

    return 0;
}
